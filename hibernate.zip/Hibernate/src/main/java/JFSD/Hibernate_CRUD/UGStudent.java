package JFSD.Hibernate_CRUD;

import jakarta.persistence.Entity;

@Entity
public class UGStudent extends Student{
	String Fname;
	String Lname;
	public String getFname() {
		return Fname;
	}
	public void setFname(String fname) {
		Fname = fname;
	}
	public String getLname() {
		return Lname;
	}
	public void setLname(String Lname) {
		Lname = Lname;
	}
	public String getSpec() {
		return Spec;
	}
	public void setSpec(String spec) {
		Spec = spec;
	}
	String Spec;
	
	

}
