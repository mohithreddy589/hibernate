package JFSD.Hibernate_CRUD;

import jakarta.persistence.Entity;

@Entity
public class PGStudent extends Student {
	
	String Fname;
	String Lname;
	String spec;
	public String getFname() {
		return Fname;
	}
	public void setFname(String fname) {
		Fname = fname;
	}
	public String getLname() {
		return Lname;
	}
	public void setLname(String lname) {
		Lname = lname;
	}
	public String getSpec() {
		return spec;
	}
	public void setSpec(String spec) {
		this.spec = spec;
	}
	
	
	

}
