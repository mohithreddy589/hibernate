package JFSD.Hibernate_CRUD;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity
public class Student {
	
	
	public String getFname() {
		return Fname;
	}
	public void setFname(String Fname) {
		Fname = Fname;
	}
	public String getLName() {
		return Lname;
	}
	public void setLName(String Lname) {
		Lname = Lname;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int id;
	String Fname;
	String Lname;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	}
	
	

