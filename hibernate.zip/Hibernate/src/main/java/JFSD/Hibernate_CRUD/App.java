package JFSD.Hibernate_CRUD;

import org.hibernate.cfg.*;
import org.hibernate.*;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;



/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) 
    {
        StandardServiceRegistry ssr= new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
        Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();  
         
        SessionFactory factory = meta.getSessionFactoryBuilder().build();
        Session session = factory.openSession();  
        Transaction t;
        Student p1=new Student();
        p1.Fname="mohith";
        p1.Lname="CSER";
        session.save(p1);
        t= session.beginTransaction();
        t.commit();
        System.out.println("Student Record Created Sucessfully");
        
        UGStudent S2=new UGStudent();
        S2.Fname="vivek";
        S2.Lname="CSE";
        session.save(S2);
        t= session.beginTransaction();
        t.commit();
        System.out.println("UG Student Record Created Sucessfully");
        
        PGStudent S3=new PGStudent();
        S3.Fname="Tharun";
        S3.Lname="IT";
        session.save(S3);
        t= session.beginTransaction();
        t.commit();
        System.out.println("PG Student Record Created Sucessfully");
    }
    	
        
        
        
        
    }

